<?php



if(isset($_POST['logout'])){
 
    require_once 'logout.php';

}

if(isset($_POST['mytopics'])){
    
    header('Location:my-topics.php');
}

if(isset($_POST['topics'])){
    
    header('Location:topics.php');
}



?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Foro SEAS</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    
    <form class="form-inline ml-auto my-2 my-lg-0" method="post">
      <button class="btn btn-outline-primary m-2 my-sm-0" name="topics" type="submit">Forum</button>
      <button class="btn btn-outline-success m-2 my-sm-0" name="mytopics" type="submit">My Topics</button>
      <button class="btn btn-outline-warning m-2 my-sm-0" name="logout" type="submit">Log out</button>
    

      <!-- <button class="btn btn-outline-primary m-2 my-sm-0" name="topics" type="submit">temas</button>
      <button class="btn btn-outline-success m-2 my-sm-0" name="topics" type="submit">Mi actividad</button>
      <button class="btn btn-outline-warning m-2 my-sm-0" name="logout" type="submit">Cerrar sesi&oacuten</button> -->
    
    </form>
  </div>
</nav>