<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/css/all.css">
</head>

<body>

    <?php include 'navigation.php'; ?>
    <?php
    require_once 'database.php';

    $usrid = 0;

    session_start();

    if (isset($_SESSION['user_id'])) {
        $usrid = $_SESSION['user_id'];
    } else {

        header('Location: index.php');
    }


    if (isset($_POST['save'])) {

        $topic_text = $_POST['topic_text'];
        $topic_data = array($topic_text, $usrid);
        if (addTopic($conn, $topic_data)) {
            echo '<div class="alert alert-success" role="alert">
            Topic Added Successfully!
      </div>';
        } else {

            echo '<div class="alert alert-danger" role="alert">
        Topic not added!
      </div>';
        }
    }


    if (isset($_POST['update'])) {
        $topic_id = $_POST['topic_id'];
        $topic_text = $_POST['topic_text'];

        if (updateTopic($conn, $topic_text, $topic_id)) {
            echo '<div class="alert alert-success" role="alert">
            Topic Updated Successfully!
      </div>';
        } else {

            echo '<div class="alert alert-danger" role="alert">
        Topic not Updated!
      </div>';
        }
    }

    if (isset($_GET['del'])) {

        if ($conn->query("DELETE from topics where `topic_id`={$_GET['del']}")) {
            echo '<div class="alert alert-success" role="alert">
                        Topic Deleted Successfully!
                </div>';
        } else {

            echo '<div class="alert alert-danger" role="alert">
                        Topic not Deleted!
                    </div>';
        }
    }


    ?>




    <div class="container-fluid mt-100">
        <div class="row">
            <div class="col-md-12">
                <h3 class="mt-3 ">Add New Topic</h3>
                <div class="card border-0   ">

                    <form method="post" class="my-4">
                        <textarea required name="topic_text" class="form-control" id="text" class="w-100" rows="3" style="resize: none;"></textarea>
                        <button type="submit" class="float-right my-2 btn btn-primary" name="save">Add Topic</button>
                        <!-- placeholder="Start Typing here (40-70 words)" -->
                    </form>



                </div>
                
                <?php

                $topics = usertopics($conn, $usrid);


                if($topics){
                    
                    echo '<h3>Update Topics</h3>';
               
                foreach ($topics as $topic) {


                ?>


                    <div class="card border-0 mt-4 mb-4">

                        <form method="post">
                            <input type="hidden" name="topic_id" value="<?php echo $topic['topic_id']; ?>">
                            <textarea required name="topic_text" class="form-control" id="text" class="w-100" rows="3" style="resize: none;"><?php echo $topic['topic_text']; ?></textarea>
                            <button type="submit" class="float-right my-2  btn btn-success m-2 " name="update">Update Topic</button>
                            <a href="my-topics.php?del=<?php echo $topic['topic_id']; ?>" class="float-right m-2  btn btn-danger">Delete</a>

                        </form>



                    </div>


                <?php }
                 } ?>
            </div>
        </div>
    </div>


    <script src="assets/js/jquery-3.6.0.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <script>




    </script>


</body>

</html>