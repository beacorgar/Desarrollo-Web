<?php
    require_once 'database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/css/all.css">
</head>
<body >

<?php include 'navigation.php'; ?>


<div class="container-fluid mt-100">
     <div class="row">
         <div class="col-md-12">

         <?php 
         
         $topics = alltopics($conn);
         
         
         foreach ($topics as $topic ) {
             
         
         ?>

         
        <div class="card mt-4 mb-4">
            <div class="card-header">
                <div class="media flex-wrap w-100 align-items-center">
                    <div class="media-body ml-3 font-weight-bold"> <?php echo topicby($conn,$topic['topic_by']); ?>
                        <div class="text-muted small">
                        <?php 
                            $date = date_create($topic['topic_date']);
                            $date =  date_format($date, "d M h:i A");
                            echo $date;
                         ?>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="card-body">
            <?php echo $topic['topic_text']; ?>
            </div>
            
             <div class="border border-top d-flex flex-wrap justify-content-between align-items-center px-0 pt-0 pb-3">
                <div class="px-4 pt-3 w-100 text-right"> <?php  echo "<a href='topic-details.php?id=$topic[0]' class='btn btn-primary'><i class='ion ion-md-create'></i>&nbsp; Comment</a>"; ?> </div>
            </div> 
        
        </div>

        
        <?php } ?>
         </div>
     </div>
 </div>


<script src="assets/js/jquery-3.6.0.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script>




</script>


</body>
</html>