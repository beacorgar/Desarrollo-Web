<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/css/all.css">
</head>

<body>
    <?php include 'navigation.php'; ?>


    <?php
    require_once 'database.php';


    $topic_id = 0;

    $usrid = 0;

    session_start();

    if (isset($_SESSION['user_id'])) {
        $usrid = $_SESSION['user_id'];
    } else {

        header('Location: index.php');
    }

    if (isset($_GET['id'])) {
        $topic_id = $_GET['id'];
    }

    if (isset($_POST['submit'])) {
        $comment = $_POST['newcomment'];
        $comment_data = array($comment, $usrid, $topic_id);
        if (addComment($conn, $comment_data)) {
            echo '<div class="alert alert-success" role="alert">
            Comment Added Successfully!
      </div>';
        } else {

            echo '<div class="alert alert-danger" role="alert">
        Comment not added!
      </div>';
        }
    }

    if (isset($_POST['update'])) {
        $comment = $_POST['editcomment'];
        $comment_id = $_POST['comment_id'];
        
        
        if (updateComment($conn, $comment, $comment_id)) {
            echo '<div class="alert alert-success" role="alert">
            Comment Updated Successfully!
      </div>';
        } else {

            echo '<div class="alert alert-danger" role="alert">
        Comment not Updated!
      </div>';
        }
    }


    if (isset($_GET['del'])) {

        if ($conn->query("DELETE from comments where `comment_id`={$_GET['del']}")) {
            echo '<div class="alert alert-success" role="alert">
                    Comment Deleted Successfully!
              </div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">
                    Comment not Deleted!
              </div>';
        }
    }




    ?>







    <div class="container-fluid mt-100">
        <div class="row">
            <div class="col-md-12">

                <?php
                $topic = gettopic($conn, $topic_id);
                if ($topic) {


                ?>


                    <div class="card mt-4 mb-4">
                        <div class="card-header">
                            <div class="media flex-wrap w-100 align-items-center">
                                <div class="media-body ml-3 font-weight-bold"> <?php echo topicby($conn, $topic['topic_by']); ?>
                                    <div class="text-muted small">
                                        <?php
                                        $date = date_create($topic['topic_date']);
                                        $date =  date_format($date, "d M h:i A");
                                        echo $date;
                                        ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="card-body">
                            <?php echo $topic['topic_text']; ?>
                        </div>

                    </div>

                    <?php }


                $comments = getcomments($conn, $topic_id);


                if ($comments) {


                    echo '<div class="text-muted h4 m-3">Comments</div>';

                    foreach ($comments as $comment) {



                    ?>

                        <div class="my-3">

                            <div class=" p-4 " style=" border-bottom: 1px solid #ccc;border-top: 1px solid #ccc;">
                                <div class=" d-inline-block font-weight-bold">
                                    <?php echo commentby($conn, $comment['comment_by']);
                                    if (($comment['comment_by']) == $usrid) {

                                        echo '&nbsp;&nbsp;&nbsp; <a href="topic-details.php?id=' . $topic_id . '&del=' . $comment['comment_id'] . '"><i class="fa fa-trash"></i></a> ';
                                        echo '&nbsp;&nbsp;&nbsp; <a href="topic-details.php?id=' . $topic_id . '&edit=' . $comment['comment_id'] . '"><i class="fa fa-pencil"></i></a> ';
                                    }

                                    ?>


                                </div>
                                <div class="text-muted d-inline-block small float-right">
                                    <?php
                                    $date = date_create($comment['comment_date']);
                                    $date =  date_format($date, "d M h:i A");
                                    echo $date;

                                    ?>
                                </div>
                                <div>

                                    <?php

                                    if (isset($_GET['edit']) &&  $_GET['edit'] == $comment['comment_id']) {
                                    echo  ' <form class=" py-3  my-lg-0" method="post" id="edit"> 
                                            <div class="mb-3">
                                            <input type="hidden" name="comment_id" value='.$comment["comment_id"].'> 
                                            <textarea autofocus="autofocus" class="form-control border border-dark" style="resize: none;" cols="10" rows="5" id="editcomment" name="editcomment" placeholder="Leave a comment" required >' .$comment['comment_text']. '</textarea> 
                                            </div> 
                                            <button class="btn btn-primary " name="update" type="update">Update</button> 
                                            <a  href="topic-details.php?id=' . $topic_id . '" class="btn btn-info">Close</a>
                                            </form>';
                                    } else
                                        echo $comment['comment_text']; ?>
                                </div>

                            </div>


                        </div>


                <?php }
                }
                ?>

                <form class=" my-4  my-lg-0" method="post">

                    <div class="mb-3">
                        <textarea class="form-control border border-dark" style="resize: none;" cols="10" rows="5" id="newcomment" name="newcomment" placeholder="Leave a comment" required></textarea>
                    </div>
                    <button class="btn btn-primary mb-4" name="submit" type="submit">Submit</button>


                </form>


            </div>
        </div>
    </div>


    <script src="assets/js/jquery-3.6.0.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <script>

    </script>


</body>

</html>