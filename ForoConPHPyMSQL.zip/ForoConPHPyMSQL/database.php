<?php

$server = 'localhost';
$username = 'beatrizcoronadogarcia';
$password = '';
$database = 'forum_database';


try {
  $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch (PDOException $e) {
  die('Connection Failed: ' . $e->getMessage());
}


//  print_r($conn->query('Select * from users where email ="beatrizcoronadogarcia@hotmail.com"')->rowCount());



function addComment($conn,$comment_data){
    
    $sql = "INSERT INTO `comments` (comment_text,comment_by,topic_id) VALUES (?,?,?)";
   
    $stmt = $conn->prepare($sql);
   
    if ($stmt->execute($comment_data)) {
        return 1;
    } else {
        return 0;
    }

}


function addTopic($conn,$topic_data){
    
    $sql = "INSERT INTO `topics` (topic_text,topic_by) VALUES (?,?)";
   
    $stmt = $conn->prepare($sql);
   
    if ($stmt->execute($topic_data)) {
        return 1;
    } else {
        return 0;
    }

}


function updateTopic($conn,$topic_text,$id){
    try{
          
        $st = $conn->prepare("UPDATE `topics` SET `topic_text`='$topic_text' where `topic_id`='$id';");
        $st->execute();
        if($st->rowCount()){
            
            return 1;
        }
        else{
            return 0;
        }
    }
    catch (Exception $ex){
        echo $ex;
    }
}

function updateComment($conn, $comment, $id){
    try{
          
        $st = $conn->prepare("UPDATE `comments` SET `comment_text`='$comment' where `comment_id`='$id';");
        $st->execute();
        if($st->rowCount()){
            
            return 1;
        }
        else{
            return 0;
        }
    }
    catch (Exception $ex){
        echo $ex;
    }


}



function alltopics($conn)
{
  $sql = "SELECT * FROM `topics` ";

        try{
            $st = $conn->query($sql);
            if($st->rowCount()>0){
                return $st->fetchAll();
            }
            else{
                return 0;
            }
        }
        catch (Exception $ex){
            echo $ex;
          
        }

}

function usertopics($conn,$usrid)
{
  $sql = "SELECT * FROM `topics` where `topic_by`=$usrid";

        try{
            $st = $conn->query($sql);
            if($st->rowCount()>0){
                return $st->fetchAll();
            }
            else{
                return 0;
            }
        }
        catch (Exception $ex){
            echo $ex;
          
        }

}



function topicby($conn,$id)
{
  $sql = "SELECT `username` FROM `users` where `id`=$id; ";

        try{
            $st = $conn->query($sql);
            if($st->rowCount()>0){
                return $st->fetch()[0];
            }
            else{
                return 0;
            }
        }
        catch (Exception $ex){
            echo $ex;
          
        }

}



function commentby($conn,$id)
{
  $sql = "SELECT `username` FROM `users` where `id`=$id; ";

        try{
            $st = $conn->query($sql);
            if($st->rowCount()>0){
                return $st->fetch()[0];
            }
            else{
                return 0;
            }
        }
        catch (Exception $ex){
            echo $ex;
          
        }

}




function gettopic($conn,$id)
{
  $sql = "SELECT * FROM `topics` where `topic_id`='$id'";

        try{
            $st = $conn->query($sql);
            
            if($st->rowCount()>0){
                return $st->fetch();
            }
            else{
                return 0;
            }
        }
        catch (Exception $ex){
            echo $ex;
          
        }

}



function getcomments($conn,$id)
{
  $sql = "SELECT * FROM `comments` where `topic_id`=$id";

        try{
            $st = $conn->query($sql);
            
            if($st->rowCount()>0){
                return $st->fetchAll();
            }
            else{
                return 0;
            }
        }
        catch (Exception $ex){
            echo $ex;
          
        }

}





?>
