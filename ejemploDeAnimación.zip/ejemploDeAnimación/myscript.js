
function Parar() {
	document.getElementById("rojo").style.animation="rojo 0s infinite linear";
	document.getElementById("rojo").style.webkitAnimation="rojo 0s infinite linear";
	document.getElementById("avion").style.animation="avion 0s infinite linear";
	document.getElementById("avion").style.webkitAnimation="avion 0s infinite linear";
}
function Iniciar() {
	document.getElementById("rojo").style.animation="rojo 10s infinite linear";
	document.getElementById("rojo").style.webkitAnimation="rojo 10s infinite linear";
	document.getElementById("avion").style.animation="avion 10s infinite linear";
	document.getElementById("avion").style.webkitAnimation="avion 10s infinite linear";
}
function cambiar_velocidad() {
	seleccion = document.formulario.velocidad.selectedIndex;
	j = document.formulario.velocidad.options[seleccion].value;
	document.getElementById("rojo").style.animation="rojo "+j+" infinite linear";
	document.getElementById("rojo").style.webkitAnimation="rojo "+j+" infinite linear";
}





